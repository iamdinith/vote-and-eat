/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritance;

/**
 *
 * @author Dinith
 */
public class Inheritance {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Triangle t1 = new Triangle();
        Triangle t2 = new Triangle("right",8.0,12.0);
        Triangle t3 = new Triangle(4.0);
        
        System.out.println("Info for t1: ");
        System.out.println("Triangle is: " + t1.style);
        System.out.println("Area is " + t1.getArea());
        
        System.out.println("Info for t2: ");
        System.out.println("Triangle is: " + t2.style);
        System.out.println("Area is " + t2.getArea());
        
        System.out.println("Info for t3: ");
        System.out.println("Triangle is: " + t3.style);
        System.out.println("Area is " + t3.getArea());
        
        Rectangle r1 = new Rectangle(3.0,4.0);
        System.out.println("Area is " + r1.getArea());
        
        

    }
    
}
