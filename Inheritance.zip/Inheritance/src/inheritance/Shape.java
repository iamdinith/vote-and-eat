/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritance;

/**
 *
 * @author Dinith
 */
public class Shape 
{
    private double width;
    private double height;
    
    public Shape()
    {
        width = 0;
        height = 0;
    }
    
    public Shape(double w, double h)
    {
        width = w;
        height = h;
    }
    
    public Shape(double x)
    {
        width = x;
        height = x;
    }
    
    public void setWidth(double w)
    {
        width = w;
    }
    
    public void setHeight(double h)
    {
        height = h;
    }
    
    public double getWidth()
    {
        return width;
    }
    
    public double getHeight()
    {
        return height;
    }
    
    @Override
    public String toString()
    {
        return("Width: " + width + " Height: " + height);
    }
}
